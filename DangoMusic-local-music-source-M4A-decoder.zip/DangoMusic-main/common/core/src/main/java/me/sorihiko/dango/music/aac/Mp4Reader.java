package me.sorihiko.dango.music.aac;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Minimal ISO-BMFF (MP4/M4A) demuxer: finds the first AAC audio track and its sample table.
 * Handles classic files (moov + stbl) and fragmented files (moof/traf/trun), and reads title/artist/album tags.
 */
final class Mp4Reader {
    final byte[] d;
    byte[] asc;
    String sampleEntry = "";
    int timescale;
    long durationUnits;
    long[] offsets = new long[0];
    int[] sizes = new int[0];
    int count;
    String title = "", artist = "", album = "";
    byte[] cover;

    private int trackId = -1;
    private int trexDefaultSize;
    private final List<long[]> moofs = new ArrayList<>();   // {moofStart, moofEnd}
    private int fill;

    private Mp4Reader(byte[] d) { this.d = d; }

    static boolean looksLikeMp4(byte[] d) {
        if (d.length < 12) return false;
        String t = new String(d, 4, 4, StandardCharsets.ISO_8859_1);
        return t.equals("ftyp") || t.equals("moov") || t.equals("mdat") || t.equals("free") || t.equals("skip") || t.equals("wide") || t.equals("styp");
    }

    static Mp4Reader parse(byte[] data) throws AacException {
        Mp4Reader r = new Mp4Reader(data);
        r.parseTop();
        if (r.asc == null) {
            if (r.sampleEntry.equals("alac")) throw new AacException("Apple Lossless (ALAC) M4A files are not supported");
            throw new AacException(r.trackId < 0 ? "No audio track found in this file" : "This file does not contain AAC audio");
        }
        for (long[] m : r.moofs) r.parseMoof((int) m[0], (int) m[1]);
        r.offsets = Arrays.copyOf(r.offsets, r.count);
        r.sizes = Arrays.copyOf(r.sizes, r.count);
        if (r.count == 0) throw new AacException("This file contains no audio samples");
        return r;
    }

    // ------------------------------------------------------------------ box helpers

    private long u32(int p) { return ((d[p] & 0xFFL) << 24) | ((d[p + 1] & 0xFF) << 16) | ((d[p + 2] & 0xFF) << 8) | (d[p + 3] & 0xFF); }
    private int i32(int p) { return (int) u32(p); }
    private int u16(int p) { return ((d[p] & 0xFF) << 8) | (d[p + 1] & 0xFF); }
    private long u64(int p) { return (u32(p) << 32) | u32(p + 4); }
    /** Type of the box that starts at p (the four bytes after its size field). */
    private String type(int p) { return new String(d, p + 4, 4, StandardCharsets.ISO_8859_1); }

    /** Box header at p: returns {payloadStart, boxEnd} or null when malformed. */
    private int[] box(int p, int limit) {
        if (p + 8 > limit) return null;
        long size = u32(p);
        int header = 8;
        if (size == 1) { if (p + 16 > limit) return null; size = u64(p + 8); header = 16; }
        else if (size == 0) size = limit - p;
        if (size < header || p + size > limit) size = Math.min(size, (long) limit - p);
        if (size < header) return null;
        return new int[]{p + header, (int) (p + size)};
    }

    private void parseTop() throws AacException {
        int p = 0;
        while (true) {
            int[] b = box(p, d.length);
            if (b == null) break;
            String t = type(p);
            if (t.equals("moov")) parseMoov(b[0], b[1]);
            else if (t.equals("moof")) moofs.add(new long[]{p, b[1]});
            p = b[1];
        }
    }

    private void parseMoov(int start, int end) throws AacException {
        for (int p = start; ; ) {
            int[] b = box(p, end);
            if (b == null) break;
            switch (type(p)) {
                case "trak": if (asc == null) parseTrak(b[0], b[1]); break;
                case "mvex": parseMvex(b[0], b[1]); break;
                case "udta": parseUdta(b[0], b[1]); break;
                default: break;
            }
            p = b[1];
        }
    }

    private void parseMvex(int start, int end) {
        for (int p = start; ; ) {
            int[] b = box(p, end);
            if (b == null) break;
            if (type(p).equals("trex") && b[1] - b[0] >= 24) trexDefaultSize = i32(b[0] + 16);
            p = b[1];
        }
    }

    private void parseTrak(int start, int end) throws AacException {
        int id = -1, ts = 0;
        long dur = 0;
        boolean audio = false;
        int stblStart = -1, stblEnd = -1;
        for (int p = start; ; ) {
            int[] b = box(p, end);
            if (b == null) break;
            String t = type(p);
            if (t.equals("tkhd")) {
                int v = d[b[0]] & 0xFF;
                id = i32(b[0] + (v == 1 ? 20 : 12));
            } else if (t.equals("mdia")) {
                for (int q = b[0]; ; ) {
                    int[] m = box(q, b[1]);
                    if (m == null) break;
                    String mt = type(q);
                    if (mt.equals("mdhd")) {
                        int v = d[m[0]] & 0xFF;
                        if (v == 1) { ts = i32(m[0] + 20); dur = u64(m[0] + 24); }
                        else { ts = i32(m[0] + 12); dur = u32(m[0] + 16); }
                    } else if (mt.equals("hdlr")) {
                        audio = new String(d, m[0] + 8, 4, StandardCharsets.ISO_8859_1).equals("soun");
                    } else if (mt.equals("minf")) {
                        for (int r = m[0]; ; ) {
                            int[] n = box(r, m[1]);
                            if (n == null) break;
                            if (type(r).equals("stbl")) { stblStart = n[0]; stblEnd = n[1]; }
                            r = n[1];
                        }
                    }
                    q = m[1];
                }
            }
            p = b[1];
        }
        if (!audio || stblStart < 0) return;
        if (trackId < 0) trackId = id;
        timescale = ts;
        durationUnits = dur;
        parseStbl(stblStart, stblEnd);
    }

    private void parseStbl(int start, int end) throws AacException {
        int[] stsz = null, stsc = null, stco = null, co64 = null;
        for (int p = start; ; ) {
            int[] b = box(p, end);
            if (b == null) break;
            switch (type(p)) {
                case "stsd": parseStsd(b[0], b[1]); break;
                case "stsz": stsz = b; break;
                case "stsc": stsc = b; break;
                case "stco": stco = b; break;
                case "co64": co64 = b; break;
                default: break;
            }
            p = b[1];
        }
        if (asc == null || stsz == null || stsc == null || (stco == null && co64 == null)) return;
        int fixed = i32(stsz[0] + 4), n = i32(stsz[0] + 8);
        if (n < 0 || n > 50_000_000) throw new AacException("Damaged MP4 sample table");
        ensure(n);
        for (int i = 0; i < n; i++) sizes[i] = fixed != 0 ? fixed : i32(stsz[0] + 12 + 4 * i);
        int chunks = i32((stco != null ? stco : co64)[0] + 4);
        int runs = i32(stsc[0] + 4);
        int sample = 0;
        for (int run = 0; run < runs && sample < n; run++) {
            int rp = stsc[0] + 8 + 12 * run;
            int first = i32(rp), per = i32(rp + 4);
            int nextFirst = run + 1 < runs ? i32(rp + 12) : chunks + 1;
            for (int chunk = first; chunk < nextFirst && sample < n; chunk++) {
                long off = stco != null ? u32(stco[0] + 8 + 4 * (chunk - 1)) : u64(co64[0] + 8 + 8 * (chunk - 1));
                for (int s = 0; s < per && sample < n; s++) {
                    offsets[sample] = off;
                    off += sizes[sample];
                    sample++;
                }
            }
        }
        count = sample;
        fill = sample;
    }

    private void parseStsd(int start, int end) {
        int p = start + 8;   // version/flags + entry count
        int[] b = box(p, end);
        if (b == null) return;
        sampleEntry = type(p);
        if (!sampleEntry.equals("mp4a")) return;
        int q = b[0] + 8;    // reserved(6) + data reference index(2)
        int version = u16(q);
        q += 20;
        if (version == 1) q += 16; else if (version == 2) q += 36;
        for (int c = q; ; ) {
            int[] cb = box(c, b[1]);
            if (cb == null) break;
            if (type(c).equals("esds")) parseEsds(cb[0] + 4, cb[1]);
            c = cb[1];
        }
    }

    private int descriptor(int[] p) {   // reads tag, advances p[0] past the length; returns payload length
        p[0]++;
        int len = 0;
        for (int i = 0; i < 4 && p[0] < d.length; i++) {
            int b = d[p[0]++] & 0xFF;
            len = (len << 7) | (b & 0x7F);
            if ((b & 0x80) == 0) break;
        }
        return len;
    }

    private void parseEsds(int start, int end) {
        int[] p = {start};
        while (p[0] < end) {
            int tag = d[p[0]] & 0xFF;
            int len = descriptor(p);
            int payload = p[0];
            if (tag == 3) {
                int flags = d[payload + 2] & 0xFF;
                int q = payload + 3;
                if ((flags & 0x80) != 0) q += 2;
                if ((flags & 0x40) != 0) q += 1 + (d[q] & 0xFF);
                if ((flags & 0x20) != 0) q += 2;
                p[0] = q;
            } else if (tag == 4) {
                int objectType = d[payload] & 0xFF;
                p[0] = payload + 13;
                if (objectType != 0x40 && objectType != 0x66 && objectType != 0x67 && objectType != 0x68) {
                    sampleEntry = "mp4a/" + Integer.toHexString(objectType);
                    return;
                }
            } else if (tag == 5) {
                asc = Arrays.copyOfRange(d, payload, Math.min(end, payload + len));
                return;
            } else {
                p[0] = payload + len;
            }
        }
    }

    // ------------------------------------------------------------------ fragmented files

    private void ensure(int n) {
        if (n > sizes.length) {
            int cap = Math.max(n, sizes.length * 2 + 16);
            sizes = Arrays.copyOf(sizes, cap);
            offsets = Arrays.copyOf(offsets, cap);
        }
    }

    private void parseMoof(int moofStart, int moofEnd) {
        int[] mb = box(moofStart, d.length);
        if (mb == null) return;
        for (int p = mb[0]; ; ) {
            int[] b = box(p, moofEnd);
            if (b == null) break;
            if (type(p).equals("traf")) parseTraf(b[0], b[1], moofStart);
            p = b[1];
        }
    }

    private void parseTraf(int start, int end, int moofStart) {
        long base = moofStart;
        int defSize = trexDefaultSize;
        boolean match = false;
        long cursor = -1;
        for (int p = start; ; ) {
            int[] b = box(p, end);
            if (b == null) break;
            String t = type(p);
            if (t.equals("tfhd")) {
                int flags = i32(b[0]) & 0xFFFFFF;
                int q = b[0] + 4;
                match = trackId < 0 || i32(q) == trackId;
                q += 4;
                if ((flags & 1) != 0) { base = u64(q); q += 8; }
                if ((flags & 2) != 0) q += 4;
                if ((flags & 8) != 0) q += 4;
                if ((flags & 0x10) != 0) { defSize = i32(q); q += 4; }
            } else if (t.equals("trun") && match) {
                int flags = i32(b[0]) & 0xFFFFFF;
                int q = b[0] + 4;
                int n = i32(q); q += 4;
                long pos = cursor >= 0 ? cursor : base;
                if ((flags & 1) != 0) { pos = base + i32(q); q += 4; }
                if ((flags & 4) != 0) q += 4;
                ensure(fill + n);
                for (int i = 0; i < n; i++) {
                    if ((flags & 0x100) != 0) q += 4;
                    int size = defSize;
                    if ((flags & 0x200) != 0) { size = i32(q); q += 4; }
                    if ((flags & 0x400) != 0) q += 4;
                    if ((flags & 0x800) != 0) q += 4;
                    if (size <= 0 || pos + size > d.length) { cursor = pos; continue; }
                    offsets[fill] = pos;
                    sizes[fill] = size;
                    fill++;
                    pos += size;
                }
                cursor = pos;
                count = fill;
            }
            p = b[1];
        }
    }

    // ------------------------------------------------------------------ tags

    private void parseUdta(int start, int end) {
        for (int p = start; ; ) {
            int[] b = box(p, end);
            if (b == null) break;
            if (type(p).equals("meta")) {
                for (int q = b[0] + 4; ; ) {
                    int[] m = box(q, b[1]);
                    if (m == null) break;
                    if (type(q).equals("ilst")) parseIlst(m[0], m[1]);
                    q = m[1];
                }
            }
            p = b[1];
        }
    }

    private void parseIlst(int start, int end) {
        for (int p = start; ; ) {
            int[] b = box(p, end);
            if (b == null) break;
            String t = new String(d, p + 4, 4, StandardCharsets.ISO_8859_1);
            for (int q = b[0]; ; ) {
                int[] m = box(q, b[1]);
                if (m == null) break;
                if (type(q).equals("data") && m[1] - m[0] >= 8) {
                    int pl = m[0] + 8;
                    int len = m[1] - pl;
                    if (t.equals("covr")) {
                        if (cover == null && len > 0) cover = Arrays.copyOfRange(d, pl, m[1]);
                    } else {
                        String s = new String(d, pl, len, StandardCharsets.UTF_8).trim();
                        if (t.equals("©nam")) title = s;
                        else if (t.equals("©ART") || (t.equals("aART") && artist.isEmpty())) artist = s;
                        else if (t.equals("©alb")) album = s;
                    }
                }
                q = m[1];
            }
            p = b[1];
        }
    }
}
