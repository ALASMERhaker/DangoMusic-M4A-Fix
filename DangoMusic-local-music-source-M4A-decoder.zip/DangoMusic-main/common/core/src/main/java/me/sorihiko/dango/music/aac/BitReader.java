package me.sorihiko.dango.music.aac;

/** MSB-first bit reader over a byte range. Reading past the end raises {@link AacException}. */
final class BitReader {
    private final byte[] buf;
    private final int start;
    private final int end;
    private int pos;

    BitReader(byte[] buf, int off, int len) {
        this.buf = buf;
        this.start = off * 8;
        this.pos = start;
        this.end = (off + len) * 8;
    }

    int bit() throws AacException {
        if (pos >= end) throw new AacException("Truncated AAC frame");
        int v = (buf[pos >> 3] >> (7 - (pos & 7))) & 1;
        pos++;
        return v;
    }

    /** Reads 0..32 bits. */
    int get(int n) throws AacException {
        if (n == 0) return 0;
        if (pos + n > end) throw new AacException("Truncated AAC frame");
        long r = 0;
        int p = pos;
        int left = n;
        while (left > 0) {
            int bitOff = p & 7;
            int take = Math.min(8 - bitOff, left);
            int cur = ((buf[p >> 3] & 0xFF) >> (8 - bitOff - take)) & ((1 << take) - 1);
            r = (r << take) | cur;
            p += take;
            left -= take;
        }
        pos = p;
        return (int) r;
    }

    void skip(int n) throws AacException {
        if (pos + n > end) throw new AacException("Truncated AAC frame");
        pos += n;
    }

    void align() { pos = start + ((pos - start + 7) & ~7); }

    int bitsLeft() { return end - pos; }
}
