package me.sorihiko.dango.music.aac;

import java.io.IOException;

/** Raised for damaged or unsupported AAC / MP4 data. The message is safe to show to the player. */
public final class AacException extends IOException {
    private static final long serialVersionUID = 1L;

    public AacException(String message) { super(message); }
}
