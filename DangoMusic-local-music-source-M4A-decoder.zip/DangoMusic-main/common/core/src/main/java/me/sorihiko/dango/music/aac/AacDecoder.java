package me.sorihiko.dango.music.aac;

import java.util.Arrays;

/**
 * Pure-Java AAC-LC decoder (ISO/IEC 14496-3, subpart 4), so M4A/AAC plays on any JVM, including
 * Android launchers whose Java runtime has no android.media classes.
 *
 * <p>Supported: long/short/start/stop windows, sine and KBD windows, section/scalefactor data,
 * pulse data, M/S and intensity stereo, perceptual noise substitution, TNS, and mono/stereo plus
 * multi-channel streams (downmixed to stereo). HE-AAC streams are decoded as their AAC-LC core
 * (no SBR/PS: the treble extension is missing, see {@link #sbrIgnored()}). Main-profile prediction,
 * LTP, gain control, and coupling channels are rejected with a clear message.
 *
 * <p>Output is normalised floating point in [-1, 1], interleaved, 1024 samples per channel per frame.
 */
public final class AacDecoder {
    public static final int FRAME = 1024;

    private static final int ONLY_LONG = 0, LONG_START = 1, EIGHT_SHORT = 2, LONG_STOP = 3;
    private static final int ZERO_HCB = 0, NOISE_HCB = 13, INTENSITY_HCB2 = 14, INTENSITY_HCB = 15;

    /** Parsed AudioSpecificConfig (or the equivalent ADTS header fields). */
    public static final class Config {
        public int objectType;
        public int sampleRateIndex;
        public int sampleRate;
        public int channelConfig;
        public boolean sbr;
        public boolean ps;
        public boolean frame960;
        /** Channels announced by an in-band program config element (channelConfig == 0). */
        public int pceChannels;

        public static Config of(int objectType, int sampleRateIndex, int channelConfig) throws AacException {
            if (sampleRateIndex < 0 || sampleRateIndex > 12) throw new AacException("Unsupported AAC sample rate");
            Config c = new Config();
            c.objectType = objectType;
            c.sampleRateIndex = sampleRateIndex;
            c.sampleRate = AacTables.SAMPLE_RATES[sampleRateIndex];
            c.channelConfig = channelConfig;
            return c;
        }
    }

    public static Config parseConfig(byte[] asc) throws AacException {
        if (asc == null || asc.length < 2) throw new AacException("Missing AAC decoder configuration");
        BitReader br = new BitReader(asc, 0, asc.length);
        Config c = new Config();
        c.objectType = br.get(5);
        if (c.objectType == 31) c.objectType = 32 + br.get(6);
        c.sampleRateIndex = br.get(4);
        if (c.sampleRateIndex == 15) {
            c.sampleRate = br.get(24);
            c.sampleRateIndex = nearestRateIndex(c.sampleRate);
        } else if (c.sampleRateIndex > 12) {
            throw new AacException("Unsupported AAC sample rate");
        } else {
            c.sampleRate = AacTables.SAMPLE_RATES[c.sampleRateIndex];
        }
        c.channelConfig = br.get(4);
        if (c.objectType == 5 || c.objectType == 29) {
            c.sbr = true;
            c.ps = c.objectType == 29;
            int extIndex = br.get(4);
            if (extIndex == 15) br.get(24);
            c.objectType = br.get(5);
            if (c.objectType == 31) c.objectType = 32 + br.get(6);
        }
        if (c.objectType != 1 && c.objectType != 2) {
            throw new AacException("Unsupported AAC profile (type " + c.objectType + "); only AAC-LC is supported");
        }
        c.frame960 = br.bit() == 1;
        if (c.frame960) throw new AacException("960-sample AAC frames are not supported");
        if (br.bit() == 1) br.get(14);          // dependsOnCoreCoder -> coreCoderDelay
        int extension = br.bit();
        if (c.channelConfig == 0) c.pceChannels = parsePce(br);
        if (extension == 1) {
            // Object types 1 and 2 carry only the (reserved) extensionFlag3 bit here.
            br.bit();
        }
        // Backward-compatible explicit SBR / PS signalling.
        try {
            if (!c.sbr && br.bitsLeft() >= 16 && br.get(11) == 0x2b7) {
                if (br.get(5) == 5 && br.bit() == 1) {
                    c.sbr = true;
                    if (br.get(4) == 15) br.get(24);
                    if (br.bitsLeft() >= 12 && br.get(11) == 0x548) c.ps = br.bit() == 1;
                }
            }
        } catch (AacException ignored) { /* a short config is fine */ }
        return c;
    }

    private static int nearestRateIndex(int rate) {
        int best = 4;
        int bestDiff = Integer.MAX_VALUE;
        for (int i = 0; i < AacTables.SAMPLE_RATES.length; i++) {
            int d = Math.abs(AacTables.SAMPLE_RATES[i] - rate);
            if (d < bestDiff) { bestDiff = d; best = i; }
        }
        return best;
    }

    /** Parses a program_config_element and returns its channel count. */
    private static int parsePce(BitReader br) throws AacException {
        br.get(4);  // element_instance_tag
        br.get(2);  // object_profile
        br.get(4);  // sampling_frequency_index
        int front = br.get(4), side = br.get(4), back = br.get(4);
        int lfe = br.get(2), assoc = br.get(3), cc = br.get(4);
        if (br.bit() == 1) br.get(4);
        if (br.bit() == 1) br.get(4);
        if (br.bit() == 1) br.get(3);
        int channels = 0;
        for (int i = 0; i < front + side + back; i++) { channels += br.bit() == 1 ? 2 : 1; br.get(4); }
        for (int i = 0; i < lfe; i++) { channels++; br.get(4); }
        for (int i = 0; i < assoc; i++) br.get(4);
        for (int i = 0; i < cc; i++) { br.get(5); }
        br.align();
        int comment = br.get(8);
        br.skip(comment * 8);
        return channels;
    }

    // ------------------------------------------------------------------ constant tables

    private static final class Huff {
        private final int[] tree;

        Huff(int[] bits, int[] codes) {
            int n = bits.length;
            tree = new int[2 * n + 2];
            int next = 1;
            for (int sym = 0; sym < n; sym++) {
                int node = 0;
                for (int b = bits[sym] - 1; b >= 0; b--) {
                    int idx = 2 * node + ((codes[sym] >> b) & 1);
                    if (b == 0) {
                        tree[idx] = ~sym;
                    } else {
                        if (tree[idx] == 0) tree[idx] = next++;
                        node = tree[idx];
                    }
                }
            }
        }

        int decode(BitReader br) throws AacException {
            int node = 0;
            while (true) {
                int v = tree[2 * node + br.bit()];
                if (v < 0) return ~v;
                if (v == 0) throw new AacException("Damaged AAC data (bad Huffman code)");
                node = v;
            }
        }
    }

    private static final Huff[] SPECTRAL = new Huff[12];
    private static final Huff SCALEFACTOR;
    private static final float[] POW43 = new float[8192];
    private static final double[] POW2_QUARTER = new double[700];   // index = x + 300, value 2^(x/4)
    private static final float[] SINE_LONG = new float[1024], SINE_SHORT = new float[128];
    private static final float[] KBD_LONG, KBD_SHORT;

    static {
        for (int i = 1; i <= 11; i++) SPECTRAL[i] = new Huff(AacTables.SPEC_BITS[i], AacTables.SPEC_CODES[i]);
        SCALEFACTOR = new Huff(AacTables.SF_BITS, AacTables.SF_CODES);
        for (int i = 0; i < POW43.length; i++) POW43[i] = (float) Math.pow(i, 4.0 / 3.0);
        for (int i = 0; i < POW2_QUARTER.length; i++) POW2_QUARTER[i] = Math.pow(2.0, (i - 300) / 4.0);
        for (int i = 0; i < 1024; i++) SINE_LONG[i] = (float) Math.sin(Math.PI * (i + 0.5) / 2048.0);
        for (int i = 0; i < 128; i++) SINE_SHORT[i] = (float) Math.sin(Math.PI * (i + 0.5) / 256.0);
        KBD_LONG = kbd(1024, 4.0);
        KBD_SHORT = kbd(128, 6.0);
    }

    /** Rising half (length n) of a Kaiser-Bessel-derived window. */
    private static float[] kbd(int n, double alpha) {
        double[] kaiser = new double[n + 1];
        double sum = 0;
        for (int p = 0; p <= n; p++) {
            double r = 2.0 * p / n - 1.0;
            kaiser[p] = bessel0(Math.PI * alpha * Math.sqrt(Math.max(0.0, 1.0 - r * r)));
            sum += kaiser[p];
        }
        float[] w = new float[n];
        double acc = 0;
        for (int i = 0; i < n; i++) {
            acc += kaiser[i];
            w[i] = (float) Math.sqrt(acc / sum);
        }
        return w;
    }

    private static double bessel0(double x) {
        double term = 1, sum = 1, q = x * x / 4.0;
        for (int k = 1; k < 60; k++) {
            term *= q / ((double) k * k);
            sum += term;
            if (term < sum * 1e-17) break;
        }
        return sum;
    }

    private static double pow2q(int x) {
        return POW2_QUARTER[Math.max(-300, Math.min(399, x)) + 300];
    }

    /** Inverse MDCT through a half-size complex FFT (a DCT-IV plus the TDAC unfolding). Unnormalised. */
    private static final class Mdct {
        final int n, h;
        final double[] preCos, preSin, postCos, postSin, twCos, twSin;
        final int[] rev;
        final double[] re, im, c;

        Mdct(int n) {
            this.n = n;
            this.h = n / 2;
            preCos = new double[h]; preSin = new double[h]; postCos = new double[h]; postSin = new double[h];
            for (int j = 0; j < h; j++) {
                double a = Math.PI * (4 * j + 1) / (4.0 * n);
                preCos[j] = Math.cos(a); preSin[j] = Math.sin(a);
                double b = Math.PI * j / n;
                postCos[j] = Math.cos(b); postSin[j] = Math.sin(b);
            }
            twCos = new double[h / 2]; twSin = new double[h / 2];
            for (int k = 0; k < h / 2; k++) {
                twCos[k] = Math.cos(2 * Math.PI * k / h);
                twSin[k] = Math.sin(2 * Math.PI * k / h);
            }
            rev = new int[h];
            int bitsCount = Integer.numberOfTrailingZeros(h);
            for (int i = 0; i < h; i++) rev[i] = Integer.reverse(i) >>> (32 - bitsCount);
            re = new double[h]; im = new double[h]; c = new double[n];
        }

        /** in[off .. off+n) -> out[0 .. 2n) */
        void imdct(float[] in, int off, double[] out) {
            for (int j = 0; j < h; j++) {
                double a = in[off + 2 * j], b = in[off + n - 1 - 2 * j];
                int r = rev[j];
                re[r] = a * preCos[j] + b * preSin[j];
                im[r] = b * preCos[j] - a * preSin[j];
            }
            for (int len = 2; len <= h; len <<= 1) {
                int half = len >> 1, step = h / len;
                for (int i = 0; i < h; i += len) {
                    for (int k = 0; k < half; k++) {
                        double wr = twCos[k * step], wi = -twSin[k * step];
                        int p = i + k, q = p + half;
                        double tr = re[q] * wr - im[q] * wi;
                        double ti = re[q] * wi + im[q] * wr;
                        re[q] = re[p] - tr; im[q] = im[p] - ti;
                        re[p] += tr; im[p] += ti;
                    }
                }
            }
            for (int p = 0; p < h; p++) {
                double ur = re[p] * postCos[p] + im[p] * postSin[p];
                double ui = im[p] * postCos[p] - re[p] * postSin[p];
                c[2 * p] = ur;
                c[n - 1 - 2 * p] = -ui;
            }
            int n2 = n / 2, n32 = 3 * n / 2;
            for (int i = 0; i < n2; i++) out[i] = c[n2 + i];
            for (int i = n2; i < n32; i++) out[i] = -c[n32 - 1 - i];
            for (int i = n32; i < 2 * n; i++) out[i] = -c[i - n32];
        }
    }

    // ------------------------------------------------------------------ decoder state

    private static final class Ics {
        int windowSequence, windowShape, maxSfb, numWindows, numGroups, numSwb, tnsMaxBands;
        final int[] groupLen = new int[8];
        int[] swb;
    }

    private static final class Chan {
        final float[] saved = new float[FRAME];
        int prevShape;
        Ics ics;
        int globalGain;
        final int[][] cb = new int[8][64];
        final float[][] scale = new float[8][64];
        final int[] q = new int[FRAME];
        final float[] coef = new float[FRAME];
        final int[] tnsFilters = new int[8];
        final int[][] tnsLen = new int[8][3], tnsOrder = new int[8][3], tnsDir = new int[8][3];
        final float[][][] tnsCoef = new float[8][3][12];
        int pulseCount;
        final int[] pulsePos = new int[4], pulseAmp = new int[4];
        boolean tnsPresent;
    }

    private final Config cfg;
    private final int srIdx;
    private final int[] swbLong, swbShort;
    private final Chan[] chans = new Chan[16];
    private final Mdct mdctLong = new Mdct(1024), mdctShort = new Mdct(128);
    private final double[] imdctBuf = new double[2048], frameBuf = new double[2048];
    private int randomState = 0x1f2e3d4c;
    private int msMaskPresent;
    private final boolean[][] msUsed = new boolean[8][64];
    private final float[][] pcm = new float[16][FRAME];
    private int pcmCount;
    private int outChannels = 2;

    public AacDecoder(Config cfg) throws AacException {
        this.cfg = cfg;
        this.srIdx = cfg.sampleRateIndex;
        this.swbLong = AacTables.SWB_LONG[srIdx];
        this.swbShort = AacTables.SWB_SHORT[srIdx];
        for (int i = 0; i < chans.length; i++) chans[i] = new Chan();
        // Mono streams stay mono; everything else is delivered as stereo (multi-channel is downmixed).
        boolean mono = cfg.channelConfig == 1 || (cfg.channelConfig == 0 && cfg.pceChannels == 1);
        outChannels = mono ? 1 : 2;
    }

    public int sampleRate() { return cfg.sampleRate; }

    /** Channels of the output (1 or 2); streams with more channels are downmixed. */
    public int channels() { return outChannels; }

    /** True when the stream is HE-AAC: only the core band is decoded, so high frequencies are missing. */
    public boolean sbrIgnored() { return cfg.sbr; }

    /** Forget overlap/window state (used after seeking). */
    public void reset() {
        for (Chan c : chans) { Arrays.fill(c.saved, 0f); c.prevShape = 0; }
    }

    /**
     * Decodes one raw_data_block into {@code out} (interleaved, normalised floats).
     * Returns samples per channel (always {@link #FRAME}); {@code out} needs FRAME * channels() entries.
     */
    public int decode(byte[] data, int off, int len, float[] out) throws AacException {
        BitReader br = new BitReader(data, off, len);
        int slot = 0;
        pcmCount = 0;
        boolean ended = false;
        while (br.bitsLeft() >= 3) {
            int id = br.get(3);
            if (id == 7) { ended = true; break; }
            switch (id) {
                case 0: case 3: {                       // SCE, LFE
                    br.get(4);
                    if (slot >= chans.length) throw new AacException("Too many AAC channels");
                    Chan c = chans[slot++];
                    c.globalGain = br.get(8);
                    c.ics = parseIcsInfo(br);
                    parseChannel(br, c);
                    prepare(c);
                    synth(c, pcm[pcmCount++]);
                    break;
                }
                case 1: {                               // CPE
                    br.get(4);
                    if (slot + 2 > chans.length) throw new AacException("Too many AAC channels");
                    Chan c0 = chans[slot++], c1 = chans[slot++];
                    int common = br.bit();
                    msMaskPresent = 0;
                    if (common == 1) {
                        Ics shared = parseIcsInfo(br);
                        c0.ics = shared; c1.ics = shared;
                        msMaskPresent = br.get(2);
                        if (msMaskPresent == 3) throw new AacException("Damaged AAC data (bad stereo mask)");
                        if (msMaskPresent == 1) {
                            for (int g = 0; g < shared.numGroups; g++)
                                for (int sfb = 0; sfb < shared.maxSfb; sfb++) msUsed[g][sfb] = br.bit() == 1;
                        } else if (msMaskPresent == 2) {
                            for (int g = 0; g < 8; g++) Arrays.fill(msUsed[g], true);
                        }
                    }
                    c0.globalGain = br.get(8);
                    if (common == 0) c0.ics = parseIcsInfo(br);
                    parseChannel(br, c0);
                    c1.globalGain = br.get(8);
                    if (common == 0) c1.ics = parseIcsInfo(br);
                    parseChannel(br, c1);
                    prepare(c0);
                    prepare(c1);
                    if (msMaskPresent != 0 || hasIntensity(c1)) stereo(c0, c1);
                    synth(c0, pcm[pcmCount++]);
                    synth(c1, pcm[pcmCount++]);
                    break;
                }
                case 2:
                    throw new AacException("AAC coupling channels are not supported");
                case 4: {                               // DSE
                    br.get(4);
                    boolean align = br.bit() == 1;
                    int count = br.get(8);
                    if (count == 255) count += br.get(8);
                    if (align) br.align();
                    br.skip(count * 8);
                    break;
                }
                case 5:                                 // PCE
                    parsePce(br);
                    break;
                case 6: {                               // FIL (extension payload, SBR data is skipped)
                    int count = br.get(4);
                    if (count == 15) count += br.get(8) - 1;
                    br.skip(Math.max(0, count) * 8);
                    break;
                }
                default:
                    throw new AacException("Damaged AAC data (bad element)");
            }
        }
        if (!ended && pcmCount == 0) {
            Arrays.fill(out, 0, FRAME * outChannels, 0f);   // empty frame
            return FRAME;
        }
        mix(out);
        return FRAME;
    }

    private void mix(float[] out) {
        int n = pcmCount;
        if (outChannels == 1 && n >= 1) {
            System.arraycopy(pcm[0], 0, out, 0, FRAME);
            return;
        }
        if (n == 1) {
            for (int i = 0; i < FRAME; i++) { out[2 * i] = pcm[0][i]; out[2 * i + 1] = pcm[0][i]; }
        } else if (n == 2) {
            for (int i = 0; i < FRAME; i++) { out[2 * i] = pcm[0][i]; out[2 * i + 1] = pcm[1][i]; }
        } else {
            // Typical order: C, L, R, (Ls, Rs | S), (LFE); downmix with the usual -3 dB weights.
            float k = 0.7071f, norm = 1f / (1f + 2f * k);
            for (int i = 0; i < FRAME; i++) {
                float c = pcm[0][i], l = pcm[1][i], r = pcm[2][i];
                float ls = n > 3 ? pcm[3][i] : 0f, rs = n > 4 ? pcm[4][i] : (n == 4 ? ls : 0f);
                out[2 * i] = (l + k * c + k * ls) * norm;
                out[2 * i + 1] = (r + k * c + k * rs) * norm;
            }
        }
    }

    // ------------------------------------------------------------------ bitstream parsing

    private Ics parseIcsInfo(BitReader br) throws AacException {
        br.bit();
        Ics ics = new Ics();
        ics.windowSequence = br.get(2);
        ics.windowShape = br.bit();
        if (ics.windowSequence == EIGHT_SHORT) {
            ics.maxSfb = br.get(4);
            int grouping = br.get(7);
            ics.numWindows = 8;
            ics.numGroups = 1;
            ics.groupLen[0] = 1;
            for (int i = 0; i < 7; i++) {
                if (((grouping >> (6 - i)) & 1) != 0) ics.groupLen[ics.numGroups - 1]++;
                else ics.groupLen[ics.numGroups++] = 1;
            }
            ics.swb = swbShort;
            ics.tnsMaxBands = AacTables.TNS_MAX_BANDS_SHORT[srIdx];
        } else {
            ics.maxSfb = br.get(6);
            if (br.bit() == 1) throw new AacException("AAC prediction (Main/LTP profile) is not supported");
            ics.numWindows = 1;
            ics.numGroups = 1;
            ics.groupLen[0] = 1;
            ics.swb = swbLong;
            ics.tnsMaxBands = AacTables.TNS_MAX_BANDS_LONG[srIdx];
        }
        ics.numSwb = ics.swb.length - 1;
        if (ics.maxSfb > ics.numSwb) throw new AacException("Damaged AAC data (bad band count)");
        return ics;
    }

    private void parseChannel(BitReader br, Chan c) throws AacException {
        Ics ics = c.ics;
        boolean shortWin = ics.windowSequence == EIGHT_SHORT;
        // section data
        int sectBits = shortWin ? 3 : 5, sectEsc = (1 << sectBits) - 1;
        for (int g = 0; g < ics.numGroups; g++) {
            int k = 0;
            while (k < ics.maxSfb) {
                int cbv = br.get(4);
                if (cbv == 12) throw new AacException("Damaged AAC data (reserved codebook)");
                int len = 0, incr;
                do { incr = br.get(sectBits); len += incr; } while (incr == sectEsc);
                if (len == 0 || k + len > ics.maxSfb) throw new AacException("Damaged AAC data (bad section)");
                for (int i = 0; i < len; i++) c.cb[g][k + i] = cbv;
                k += len;
            }
        }
        // scalefactors
        int sf = c.globalGain, noise = c.globalGain - 90, isPos = 0;
        boolean firstNoise = true;
        for (int g = 0; g < ics.numGroups; g++) {
            for (int sfb = 0; sfb < ics.maxSfb; sfb++) {
                int cb = c.cb[g][sfb];
                switch (cb) {
                    case ZERO_HCB:
                        c.scale[g][sfb] = 0f;
                        break;
                    case INTENSITY_HCB: case INTENSITY_HCB2:
                        isPos += SCALEFACTOR.decode(br) - 60;
                        isPos = Math.max(-155, Math.min(100, isPos));
                        c.scale[g][sfb] = (float) ((cb == INTENSITY_HCB ? 1.0 : -1.0) * pow2q(-isPos));
                        break;
                    case NOISE_HCB:
                        if (firstNoise) { noise += br.get(9) - 256; firstNoise = false; }
                        else noise += SCALEFACTOR.decode(br) - 60;
                        c.scale[g][sfb] = (float) pow2q(Math.max(-100, Math.min(155, noise)));
                        break;
                    default:
                        sf += SCALEFACTOR.decode(br) - 60;
                        if (sf < 0 || sf > 255) throw new AacException("Damaged AAC data (scalefactor out of range)");
                        c.scale[g][sfb] = (float) pow2q(sf - 100);
                }
            }
        }
        // pulse data
        c.pulseCount = 0;
        if (br.bit() == 1) {
            if (shortWin) throw new AacException("Damaged AAC data (pulse in short window)");
            int n = br.get(2) + 1;
            int startSfb = br.get(6);
            if (startSfb >= ics.numSwb) throw new AacException("Damaged AAC data (bad pulse band)");
            int pos = ics.swb[startSfb];
            for (int i = 0; i < n; i++) {
                pos += br.get(5);
                int amp = br.get(4);
                if (pos >= FRAME) throw new AacException("Damaged AAC data (bad pulse position)");
                c.pulsePos[i] = pos;
                c.pulseAmp[i] = amp;
            }
            c.pulseCount = n;
        }
        // TNS
        c.tnsPresent = br.bit() == 1;
        if (c.tnsPresent) {
            int filtBits = shortWin ? 1 : 2, lenBits = shortWin ? 4 : 6, orderBits = shortWin ? 3 : 5;
            for (int w = 0; w < ics.numWindows; w++) {
                int n = br.get(filtBits);
                c.tnsFilters[w] = n;
                if (n == 0) continue;
                int res = br.bit() + 3;
                for (int f = 0; f < n; f++) {
                    c.tnsLen[w][f] = br.get(lenBits);
                    int order = br.get(orderBits);
                    if (order > 12) throw new AacException("Damaged AAC data (bad TNS order)");
                    c.tnsOrder[w][f] = order;
                    if (order == 0) continue;
                    c.tnsDir[w][f] = br.bit();
                    int compress = br.bit();
                    int bits = res - compress;
                    double iq = ((1 << (res - 1)) - 0.5) / (Math.PI / 2), iqm = ((1 << (res - 1)) + 0.5) / (Math.PI / 2);
                    for (int i = 0; i < order; i++) {
                        int v = br.get(bits);
                        if (v >= (1 << (bits - 1))) v -= 1 << bits;
                        c.tnsCoef[w][f][i] = (float) Math.sin(v / (v >= 0 ? iq : iqm));
                    }
                }
            }
        }
        if (br.bit() == 1) throw new AacException("AAC gain control (SSR profile) is not supported");
        // spectral data
        Arrays.fill(c.q, 0);
        int winStart = 0;
        for (int g = 0; g < ics.numGroups; g++) {
            int glen = ics.groupLen[g];
            for (int sfb = 0; sfb < ics.maxSfb; sfb++) {
                int cb = c.cb[g][sfb];
                if (cb == ZERO_HCB || cb >= NOISE_HCB) continue;
                int start = ics.swb[sfb], width = ics.swb[sfb + 1] - start;
                for (int w = 0; w < glen; w++) decodeBand(br, cb, c.q, (winStart + w) * 128 + start, width);
            }
            winStart += glen;
        }
    }

    private void decodeBand(BitReader br, int cb, int[] q, int base, int width) throws AacException {
        Huff h = SPECTRAL[cb];
        if (cb <= 4) {
            for (int k = 0; k < width; k += 4) {
                int idx = h.decode(br);
                int a, b, c, d;
                if (cb <= 2) {
                    a = idx / 27 - 1; b = (idx / 9) % 3 - 1; c = (idx / 3) % 3 - 1; d = idx % 3 - 1;
                } else {
                    a = idx / 27; b = (idx / 9) % 3; c = (idx / 3) % 3; d = idx % 3;
                    if (a != 0 && br.bit() == 1) a = -a;
                    if (b != 0 && br.bit() == 1) b = -b;
                    if (c != 0 && br.bit() == 1) c = -c;
                    if (d != 0 && br.bit() == 1) d = -d;
                }
                q[base + k] = a; q[base + k + 1] = b; q[base + k + 2] = c; q[base + k + 3] = d;
            }
            return;
        }
        for (int k = 0; k < width; k += 2) {
            int idx = h.decode(br);
            int y, z;
            if (cb <= 6) {
                y = idx / 9 - 4; z = idx % 9 - 4;
            } else {
                int radix = cb <= 8 ? 8 : cb <= 10 ? 13 : 17;
                y = idx / radix; z = idx % radix;
                boolean ny = y != 0 && br.bit() == 1;
                boolean nz = z != 0 && br.bit() == 1;
                if (cb == 11) {
                    if (y == 16) y = escape(br);
                    if (z == 16) z = escape(br);
                }
                if (ny) y = -y;
                if (nz) z = -z;
            }
            q[base + k] = y; q[base + k + 1] = z;
        }
    }

    private static int escape(BitReader br) throws AacException {
        int n = 4;
        while (br.bit() == 1) {
            n++;
            if (n > 16) throw new AacException("Damaged AAC data (bad escape code)");
        }
        return (1 << n) + br.get(n);
    }

    // ------------------------------------------------------------------ dequantisation and tools

    /** Pulses, inverse quantisation and noise substitution: quantised values -> spectrum. */
    private void prepare(Chan c) {
        Ics ics = c.ics;
        for (int i = 0; i < c.pulseCount; i++) {
            int pos = c.pulsePos[i];
            if (c.q[pos] > 0) c.q[pos] += c.pulseAmp[i]; else c.q[pos] -= c.pulseAmp[i];
        }
        float[] coef = c.coef;
        Arrays.fill(coef, 0f);
        int winStart = 0;
        for (int g = 0; g < ics.numGroups; g++) {
            int glen = ics.groupLen[g];
            for (int sfb = 0; sfb < ics.maxSfb; sfb++) {
                int cb = c.cb[g][sfb];
                if (cb == ZERO_HCB || cb > NOISE_HCB) continue;
                int start = ics.swb[sfb], width = ics.swb[sfb + 1] - start;
                float scale = c.scale[g][sfb];
                for (int w = 0; w < glen; w++) {
                    int base = (winStart + w) * 128 + start;
                    if (cb == NOISE_HCB) {
                        double energy = 0;
                        for (int k = 0; k < width; k++) {
                            randomState = randomState * 1664525 + 1013904223;
                            coef[base + k] = randomState;
                            energy += (double) coef[base + k] * coef[base + k];
                        }
                        float s = (float) (scale / Math.sqrt(energy));
                        for (int k = 0; k < width; k++) coef[base + k] *= s;
                    } else {
                        for (int k = 0; k < width; k++) {
                            int v = c.q[base + k];
                            if (v == 0) continue;
                            int a = v < 0 ? -v : v;
                            float mag = a < POW43.length ? POW43[a] : (float) Math.pow(a, 4.0 / 3.0);
                            coef[base + k] = (v < 0 ? -mag : mag) * scale;
                        }
                    }
                }
            }
            winStart += glen;
        }
    }

    private boolean hasIntensity(Chan c1) {
        Ics ics = c1.ics;
        for (int g = 0; g < ics.numGroups; g++)
            for (int sfb = 0; sfb < ics.maxSfb; sfb++)
                if (c1.cb[g][sfb] >= INTENSITY_HCB2) return true;
        return false;
    }

    /** Mid/side and intensity stereo for a channel pair sharing window grouping. */
    private void stereo(Chan c0, Chan c1) {
        Ics ics = c0.ics;
        int winStart = 0;
        for (int g = 0; g < ics.numGroups; g++) {
            int glen = ics.groupLen[g];
            for (int sfb = 0; sfb < ics.maxSfb; sfb++) {
                int start = ics.swb[sfb], width = ics.swb[sfb + 1] - start;
                int cb0 = c0.cb[g][sfb], cb1 = c1.cb[g][sfb];
                boolean ms = msMaskPresent != 0 && msUsed[g][sfb];
                if (ms && cb0 < NOISE_HCB && cb1 < NOISE_HCB) {
                    for (int w = 0; w < glen; w++) {
                        int base = (winStart + w) * 128 + start;
                        for (int k = 0; k < width; k++) {
                            float l = c0.coef[base + k], r = c1.coef[base + k];
                            c0.coef[base + k] = l + r;
                            c1.coef[base + k] = l - r;
                        }
                    }
                }
                if (cb1 >= INTENSITY_HCB2) {
                    float scale = c1.scale[g][sfb] * (ms ? -1f : 1f);
                    for (int w = 0; w < glen; w++) {
                        int base = (winStart + w) * 128 + start;
                        for (int k = 0; k < width; k++) c1.coef[base + k] = c0.coef[base + k] * scale;
                    }
                }
            }
            winStart += glen;
        }
    }

    private void applyTns(Chan c) {
        Ics ics = c.ics;
        int mmm = Math.min(ics.tnsMaxBands, ics.maxSfb);
        double[] lpc = new double[12];
        for (int w = 0; w < ics.numWindows; w++) {
            int bottom = ics.numSwb;
            for (int f = 0; f < c.tnsFilters[w]; f++) {
                int top = bottom;
                bottom = Math.max(0, top - c.tnsLen[w][f]);
                int order = c.tnsOrder[w][f];
                if (order == 0) continue;
                // reflection coefficients -> direct-form LPC (step-up recursion)
                for (int i = 0; i < order; i++) {
                    double r = c.tnsCoef[w][f][i];
                    lpc[i] = r;
                    for (int j = 0; j < (i + 1) >> 1; j++) {
                        double a = lpc[j], b = lpc[i - 1 - j];
                        lpc[j] = a + r * b;
                        lpc[i - 1 - j] = b + r * a;
                    }
                }
                int start = ics.swb[Math.min(bottom, mmm)], end = ics.swb[Math.min(top, mmm)];
                int size = end - start;
                if (size <= 0) continue;
                int inc = 1;
                if (c.tnsDir[w][f] != 0) { inc = -1; start = end - 1; }
                start += w * 128;
                for (int m = 0; m < size; m++, start += inc) {
                    double acc = c.coef[start];
                    int lim = Math.min(m, order);
                    for (int i = 1; i <= lim; i++) acc -= c.coef[start - inc * i] * lpc[i - 1];
                    c.coef[start] = (float) acc;
                }
            }
        }
    }

    // ------------------------------------------------------------------ filterbank

    private static final double OUT_SCALE_LONG = 1.0 / (1024.0 * 32768.0), OUT_SCALE_SHORT = 1.0 / (128.0 * 32768.0);

    private void synth(Chan c, float[] out) {
        if (c.tnsPresent) applyTns(c);
        Ics ics = c.ics;
        float[] longPrev = c.prevShape == 1 ? KBD_LONG : SINE_LONG, longCur = ics.windowShape == 1 ? KBD_LONG : SINE_LONG;
        float[] shortPrev = c.prevShape == 1 ? KBD_SHORT : SINE_SHORT, shortCur = ics.windowShape == 1 ? KBD_SHORT : SINE_SHORT;
        double[] buf = frameBuf;
        Arrays.fill(buf, 0.0);
        if (ics.windowSequence != EIGHT_SHORT) {
            mdctLong.imdct(c.coef, 0, imdctBuf);
            for (int n = 0; n < 2048; n++) {
                double w;
                switch (ics.windowSequence) {
                    case ONLY_LONG:
                        w = n < 1024 ? longPrev[n] : longCur[2047 - n];
                        break;
                    case LONG_START:
                        w = n < 1024 ? longPrev[n] : n < 1472 ? 1.0 : n < 1600 ? shortCur[1599 - n] : 0.0;
                        break;
                    default:    // LONG_STOP
                        w = n < 448 ? 0.0 : n < 576 ? shortPrev[n - 448] : n < 1024 ? 1.0 : longCur[2047 - n];
                }
                buf[n] = imdctBuf[n] * w * OUT_SCALE_LONG;
            }
        } else {
            for (int w = 0; w < 8; w++) {
                mdctShort.imdct(c.coef, w * 128, imdctBuf);
                int base = 448 + 128 * w;
                for (int n = 0; n < 256; n++) {
                    double win = n < 128 ? (w == 0 ? shortPrev[n] : shortCur[n]) : shortCur[255 - n];
                    buf[base + n] += imdctBuf[n] * win * OUT_SCALE_SHORT;
                }
            }
        }
        for (int i = 0; i < FRAME; i++) {
            out[i] = (float) (buf[i] + c.saved[i]);
            c.saved[i] = (float) buf[FRAME + i];
        }
        c.prevShape = ics.windowShape;
    }
}
