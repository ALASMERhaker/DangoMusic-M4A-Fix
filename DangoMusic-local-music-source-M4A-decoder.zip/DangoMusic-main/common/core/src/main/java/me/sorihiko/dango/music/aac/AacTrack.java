package me.sorihiko.dango.music.aac;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

/**
 * An AAC audio stream inside an MP4/M4A container or a raw ADTS (.aac) file, decoded frame by frame.
 * Not thread-safe: one reader, sequential {@link #read} calls, optional {@link #seekMs}.
 */
public final class AacTrack {
    private final byte[] data;
    private final long[] offsets;
    private final int[] sizes;
    private final int count;
    private final AacDecoder decoder;
    private final float[] floats = new float[AacDecoder.FRAME * 2];
    private int next;
    private int bad;

    public final String title, artist, album;
    public final byte[] cover;
    public final boolean sbrIgnored;

    private AacTrack(byte[] data, long[] offsets, int[] sizes, int count, AacDecoder decoder,
                     String title, String artist, String album, byte[] cover) {
        this.data = data;
        this.offsets = offsets;
        this.sizes = sizes;
        this.count = count;
        this.decoder = decoder;
        this.title = title;
        this.artist = artist;
        this.album = album;
        this.cover = cover;
        this.sbrIgnored = decoder.sbrIgnored();
    }

    /** True for data that looks like MP4/M4A or ADTS AAC. */
    public static boolean recognizes(byte[] data) {
        return Mp4Reader.looksLikeMp4(data) || adtsStart(data) >= 0;
    }

    public static AacTrack open(byte[] data) throws AacException {
        if (Mp4Reader.looksLikeMp4(data)) {
            Mp4Reader r = Mp4Reader.parse(data);
            AacDecoder decoder = new AacDecoder(AacDecoder.parseConfig(r.asc));
            return new AacTrack(data, r.offsets, r.sizes, r.count, decoder, r.title, r.artist, r.album, r.cover);
        }
        int first = adtsStart(data);
        if (first < 0) throw new AacException("Not an AAC file");
        return openAdts(data, first);
    }

    // ------------------------------------------------------------------ ADTS

    private static int adtsStart(byte[] d) {
        int p = 0;
        if (d.length > 10 && d[0] == 'I' && d[1] == 'D' && d[2] == '3') {
            p = 10 + (((d[6] & 0x7F) << 21) | ((d[7] & 0x7F) << 14) | ((d[8] & 0x7F) << 7) | (d[9] & 0x7F));
        }
        for (int i = p; i + 7 < d.length && i < p + 4096; i++) {
            if ((d[i] & 0xFF) == 0xFF && (d[i + 1] & 0xF6) == 0xF0) {
                int len = adtsFrameLength(d, i);
                if (len < 7) continue;
                // require another header right after, to avoid false positives inside other data
                if (i + len + 1 < d.length && (d[i + len] & 0xFF) == 0xFF && (d[i + len + 1] & 0xF6) == 0xF0) return i;
                if (i + len >= d.length - 1) return i;
            }
        }
        return -1;
    }

    private static int adtsFrameLength(byte[] d, int i) {
        return ((d[i + 3] & 3) << 11) | ((d[i + 4] & 0xFF) << 3) | ((d[i + 5] & 0xFF) >> 5);
    }

    private static AacTrack openAdts(byte[] d, int start) throws AacException {
        int profile = ((d[start + 2] >> 6) & 3) + 1;
        int rate = (d[start + 2] >> 2) & 15;
        int channels = ((d[start + 2] & 1) << 2) | ((d[start + 3] >> 6) & 3);
        if (profile != 1 && profile != 2) throw new AacException("Unsupported AAC profile; only AAC-LC is supported");
        AacDecoder.Config cfg = AacDecoder.Config.of(profile, rate, channels);
        long[] offs = new long[1024];
        int[] sz = new int[1024];
        int n = 0, p = start;
        while (p + 7 <= d.length) {
            if ((d[p] & 0xFF) != 0xFF || (d[p + 1] & 0xF6) != 0xF0) {
                int q = p + 1;                                  // resync
                while (q + 1 < d.length && !((d[q] & 0xFF) == 0xFF && (d[q + 1] & 0xF6) == 0xF0)) q++;
                p = q;
                continue;
            }
            int len = adtsFrameLength(d, p);
            int header = (d[p + 1] & 1) == 0 ? 9 : 7;
            if (len < header || p + len > d.length) break;
            if (n == offs.length) { offs = Arrays.copyOf(offs, n * 2); sz = Arrays.copyOf(sz, n * 2); }
            offs[n] = p + header;
            sz[n] = len - header;
            n++;
            p += len;
        }
        if (n == 0) throw new AacException("No AAC frames found");
        return new AacTrack(d, offs, sz, n, new AacDecoder(cfg), "", "", "", null);
    }

    // ------------------------------------------------------------------ playback

    public int sampleRate() { return decoder.sampleRate(); }
    public int channels() { return decoder.channels(); }
    public int frameCount() { return count; }
    public double frameMs() { return AacDecoder.FRAME * 1000.0 / decoder.sampleRate(); }
    public long durationMs() { return (long) count * AacDecoder.FRAME * 1000L / decoder.sampleRate(); }

    /**
     * Decodes the next frame to 16-bit interleaved PCM and returns the number of shorts written, or -1 at the end.
     * A single damaged frame becomes silence instead of an exception; many in a row throw.
     */
    public int read(short[] out) throws AacException {
        int n = readFloat(floats);
        if (n < 0) return -1;
        for (int i = 0; i < n; i++) {
            float v = floats[i] * 32768f;
            out[i] = (short) (v >= 32767f ? 32767 : v <= -32768f ? -32768 : Math.round(v));
        }
        return n;
    }

    /** Float variant (normalised to [-1, 1]); also what the unit tests compare against ffmpeg. */
    public int readFloat(float[] out) throws AacException {
        if (next >= count) return -1;
        int n = AacDecoder.FRAME * decoder.channels();
        try {
            decoder.decode(data, (int) offsets[next], sizes[next], out);
            bad = 0;
        } catch (AacException e) {
            if (++bad > 50) throw e;
            Arrays.fill(out, 0, n, 0f);
            decoder.reset();
        }
        next++;
        return n;
    }

    /** Moves to the frame containing {@code ms}; two lead-in frames are decoded and dropped to rebuild the overlap. */
    public double seekMs(long ms) throws AacException {
        int target = (int) Math.max(0, Math.min(count - 1, Math.floor(ms / frameMs())));
        decoder.reset();
        next = Math.max(0, target - 2);
        short[] scratch = new short[AacDecoder.FRAME * 2];
        while (next < target) read(scratch);
        return target * frameMs();
    }

    // ------------------------------------------------------------------ cheap probing

    /** Reads only the movie header of an M4A file; returns 0 when the length cannot be found cheaply. */
    public static long probeDurationMs(File file) {
        try (RandomAccessFile f = new RandomAccessFile(file, "r")) {
            long pos = 0, len = f.length();
            byte[] head = new byte[16];
            while (pos + 8 <= len) {
                f.seek(pos);
                f.readFully(head, 0, 8);
                long size = ((head[0] & 0xFFL) << 24) | ((head[1] & 0xFF) << 16) | ((head[2] & 0xFF) << 8) | (head[3] & 0xFF);
                String type = new String(head, 4, 4, StandardCharsets.ISO_8859_1);
                int header = 8;
                if (size == 1) {
                    f.readFully(head, 8, 8);
                    size = 0;
                    for (int i = 8; i < 16; i++) size = (size << 8) | (head[i] & 0xFF);
                    header = 16;
                } else if (size == 0) {
                    size = len - pos;
                }
                if (size < header) return 0;
                if (type.equals("moov")) {
                    if (size > 64L * 1024 * 1024) return 0;
                    byte[] moov = new byte[(int) size];
                    f.seek(pos);
                    f.readFully(moov);
                    return moovDurationMs(moov);
                }
                pos += size;
            }
        } catch (IOException | RuntimeException ignored) { }
        return 0;
    }

    private static long moovDurationMs(byte[] moov) {
        try {
            byte[] file = new byte[16 + moov.length];       // a minimal ftyp + moov so the normal parser applies
            file[3] = 16; file[4] = 'f'; file[5] = 't'; file[6] = 'y'; file[7] = 'p'; file[8] = 'M'; file[9] = '4'; file[10] = 'A'; file[11] = ' ';
            System.arraycopy(moov, 0, file, 16, moov.length);
            Mp4Reader r = Mp4Reader.parse(file);
            return r.count * (long) AacDecoder.FRAME * 1000L / AacDecoder.parseConfig(r.asc).sampleRate;
        } catch (IOException | RuntimeException e) {
            return 0;
        }
    }
}
