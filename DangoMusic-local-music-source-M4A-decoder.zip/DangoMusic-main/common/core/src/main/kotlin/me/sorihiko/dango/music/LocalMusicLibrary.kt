package me.sorihiko.dango.music

import java.io.File
import java.security.MessageDigest
import java.util.Locale
import java.nio.file.Files
import java.nio.file.Path
import java.nio.charset.StandardCharsets

/** Device-local music library. Scans the configured directory recursively. */
object LocalMusicLibrary {
    private const val DEFAULT_ROOT = "/storage/emulated/0/VidMate/download"
    @Volatile var rootPath: String = DEFAULT_ROOT
        private set
    @Volatile private var configFile: Path? = null
    @Volatile var tracks: List<NeteaseTrack> = emptyList()
        private set
    @Volatile var status: String = ""
        private set

    private val supported = setOf("mp3", "flac", "ogg", "m4a", "aac")

    /** Load the player's editable local-music folder from its normal config directory. */
    @Synchronized fun configure(configDir: Path) {
        val file = configDir.resolve("local-music-path.txt")
        if (configFile == file) return
        configFile = file
        try {
            if (Files.isRegularFile(file)) {
                val saved = String(Files.readAllBytes(file), StandardCharsets.UTF_8).trim()
                if (saved.isNotEmpty()) rootPath = saved
            }
        } catch (_: Exception) { }
    }

    @Synchronized fun setRootPath(path: String): Boolean {
        val clean = path.trim().removeSuffix("/").ifEmpty { "/" }
        if (clean.any { it == '\n' || it == '\r' || it == '\u0000' }) {
            status = "Invalid folder path"
            return false
        }
        val root = File(clean)
        if (!root.exists() || !root.isDirectory || !root.canRead()) {
            status = "Folder unavailable or permission denied: $clean"
            return false
        }
        rootPath = clean
        try {
            configFile?.let { file ->
                Files.createDirectories(file.parent)
                Files.write(file, clean.toByteArray(StandardCharsets.UTF_8))
            }
        } catch (e: Exception) {
            status = "Could not save folder path: ${e.message ?: "unknown error"}"
            return false
        }
        scan()
        return true
    }

    @Synchronized fun scan(): List<NeteaseTrack> {
        val root = File(rootPath)
        if (!root.exists() || !root.isDirectory || !root.canRead()) {
            tracks = emptyList()
            status = "Folder unavailable or permission denied: $rootPath"
            return tracks
        }
        val found = ArrayList<File>()
        try {
            root.walkTopDown().onEnter { it.canRead() }.forEach { file ->
                if (file.isFile && file.extension.lowercase(Locale.ROOT) in supported && file.canRead()) found += file
            }
        } catch (e: SecurityException) {
            tracks = emptyList()
            status = "Storage permission denied: ${e.message ?: "cannot read folder"}"
            return tracks
        }
        found.sortBy { it.relativeTo(root).path.lowercase(Locale.ROOT) }
        tracks = found.map { file ->
            val path = try { file.canonicalPath } catch (_: Exception) { file.absolutePath }
            val digest = MessageDigest.getInstance("SHA-256").digest(path.toByteArray(Charsets.UTF_8))
            val id = (digest.take(8).fold(0L) { acc, b -> (acc shl 8) or (b.toLong() and 255L) } and Long.MAX_VALUE).coerceAtLeast(1L)
            val title = file.nameWithoutExtension.ifBlank { file.name }
            val split = title.split(" - ", limit = 2)
            val artist = if (split.size == 2) split[0].trim() else ""
            val name = if (split.size == 2) split[1].trim() else title
            NeteaseTrack(id, name, if (artist.isEmpty()) emptyList() else listOf(artist), scanDuration(file), "").apply {
                localPath = path
            }
        }
        status = if (tracks.isEmpty()) "No supported audio files found in $rootPath" else "Found ${tracks.size} local audio files"
        return tracks
    }

    /**
     * Cheap length probe for the list (only reads the file header). Returns 0 when it is not cheaply known;
     * the player then measures the real length when the track is opened.
     */
    fun scanDuration(file: File): Long = try {
        when (file.extension.lowercase(Locale.ROOT)) {
            "m4a", "mp4", "aac" -> me.sorihiko.dango.music.aac.AacTrack.probeDurationMs(file)
            "flac" -> flacDuration(file)
            else -> 0L
        }
    } catch (_: Throwable) { 0L }

    private fun flacDuration(file: File): Long {
        val head = ByteArray(42)
        java.io.RandomAccessFile(file, "r").use { it.readFully(head) }
        if (head[0] != 'f'.code.toByte() || head[1] != 'L'.code.toByte() || head[2] != 'a'.code.toByte() || head[3] != 'C'.code.toByte()) return 0L
        if ((head[4].toInt() and 127) != 0) return 0L
        val packed = java.nio.ByteBuffer.wrap(head, 18, 8).long
        val rate = packed ushr 44
        val samples = packed and ((1L shl 36) - 1)
        return if (rate in 8000..192000 && samples > 0) samples * 1000 / rate else 0L
    }
}
