package me.sorihiko.dango.musicui

import me.sorihiko.dango.i18n.I18n

import me.sorihiko.dango.module.impls.music.NeteaseMusicModule
import me.sorihiko.dango.music.CoverCache
import me.sorihiko.dango.music.MusicPlayer
import me.sorihiko.dango.music.MusicScreen
import me.sorihiko.dango.music.MusicSource
import me.sorihiko.dango.music.MusicSources
import me.sorihiko.dango.music.NeteaseApi
import me.sorihiko.dango.ui.LayoutBounds
import me.sorihiko.dango.ui.ShadowStyle
import me.sorihiko.dango.ui.ShapeStyle
import me.sorihiko.dango.ui.Theme
import me.sorihiko.dango.ui.Vec2
import me.sorihiko.dango.utils.Color

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** 底部播放栏：左边当前歌曲，中间控制按钮 + 进度条，右边单曲循环 / 随机 + 音量 */
internal class PlayerBar(private val screen: MusicScreen, private val module: NeteaseMusicModule) {
    private val ui = screen.ui
    /** 变速变调、均衡器的按钮和面板（同时只开一个） */
    val tune = TunePanel(ui).also { t -> t.onOpen = { eq.open = false; add.open = false; quality.open = false } }
    val eq: EqPanel = EqPanel(ui).also { e -> e.onOpen = { tune.open = false; add.open = false; quality.open = false } }
    /** 红心旁边的"+"：加到自建歌单 */
    val add: AddPanel = AddPanel(ui).also { a -> a.onOpen = { tune.open = false; eq.open = false; quality.open = false } }
    /** 右边的音质标签：给当前这首换音质 */
    val quality: QualityPanel = QualityPanel(ui).also { q -> q.onOpen = { tune.open = false; eq.open = false; add.open = false } }
    /** 开着的那个面板（没开是空的）：画下面的内容时鼠标在这里不算悬停 */
    val popupRect: LayoutBounds get() = listOf(eq.panelRect, tune.panelRect, add.panelRect, quality.panelRect).firstOrNull { it.width > 0f } ?: LayoutBounds()

    private var lastSubtitle = ""
    private var subtitleAt = 0L
    private var lastSkipNotice = 0L
    private var lastBlockedNotice = 0L
    private var failedMembers = emptySet<String>()
    private var progRect = LayoutBounds()
    private var volRect = LayoutBounds()
    /** 正在拖进度条：拖的时候只移动显示的位置，松开才真正跳过去（拖动过程中不反复重新解码） */
    private var seeking = false
    private var seekFraction = 0f

    /** 一个按钮的动画：悬停底圈渐显、点击先缩再弹回、开关类按钮的选中颜色渐变 */
    private class Anim {
        val hover = Spring(300f, 26f)
        val press = Spring(420f, 13f)
        val on = Spring(240f, 24f)
    }
    private val prevA = Anim()
    private val playA = Anim()
    private val nextA = Anim()
    private val queueA = Anim()
    private val shuffleA = Anim()
    private val repeatA = Anim()
    private val modeA = Anim()
    private val likeA = Anim()
    /** 播放 ↔ 暂停图标的过渡 */
    private val playMorph = Spring(320f, 26f)
    /** 进度条上的圆钮：鼠标移上去时渐显 */
    private val progKnob = Spring(300f, 26f)

    fun draw(bar: LayoutBounds) {
        val ctx = ui.ctx
        drawPanel(bar)
        val t = MusicPlayer.shownTrack
        // 上面一排放封面、按钮和音量（中线在 [ry]），下面是横贯整条栏的进度条
        val ry = bar.y + 34f

        // 左：封面 + 歌名 / 歌手
        val cs = 48f
        // 左边封面和右边音量都往里收，和下面进度条的两头对齐
        val coverBox = LayoutBounds(bar.x + PROGRESS_INSET, ry - cs / 2f, cs, cs)
        ui.drawCover(coverBox, t?.let { CoverCache.trackRounded(it, 0.27f) }, 13f)
        ctx.drawShape(coverBox, ShapeStyle(Color.TRANSPARENT, 13f, 1f, Color(1f, 1f, 1f, 0.10f)))
        val infoX = coverBox.right + 12f
        // 窗口窄时歌名区跟着缩短，别压到中间的按钮上（红心也要留位置）
        // 左边界：播放模式按钮（中间那组最左边）再留一点空
        val leftLimit = bar.x + bar.width / 2f - 136f
        // 歌名后面的小按钮：网易云红心、加到歌单的 +；放不下（窗口太窄）就不显示，免得压到播放模式按钮
        val likeWanted = t != null && !MusicPlayer.external && MusicSources.api(t.source).canLike
        val addWanted = add.available(t)
        val room = leftLimit - infoX - 40f - 12f
        val likeShown = likeWanted && room >= 32f
        val addShown = addWanted && room >= (if (likeShown) 64f else 32f)
        if (!addShown) add.open = false
        val extras = (if (likeShown) 32f else 0f) + (if (addShown) 32f else 0f)
        val infoW = (leftLimit - infoX - extras - (if (extras > 0f) 12f else 8f)).coerceIn(40f, 220f)
        val title = t?.name ?: I18n.text("Not playing")
        ui.text(ui.trim(title, infoW, 13f, Theme.FONT_SEMIBOLD), infoX, coverBox.y + 9f, 13f, Theme.TEXT_PRIMARY, Theme.FONT_SEMIBOLD)
        val sub = when {
            t == null -> "-"
            !MusicPlayer.external && MusicPlayer.message.isNotEmpty() -> I18n.message(MusicPlayer.message)
            else -> t.artists.joinToString(" / ")
        }
        // 一起听：房主没开"允许成员控制"时点了切歌 / 暂停 / 拖进度
        val blockedAt = MusicPlayer.blockedNotice
        if (lastBlockedNotice != blockedAt) {
            lastBlockedNotice = blockedAt
            if (blockedAt != 0L) Library.showTemporaryStatus(I18n.text("The host has turned off member control. You can only follow the host's music."), 3_000L)
        }
        val skipAt = MusicPlayer.skipNotice
        if (lastSkipNotice != skipAt) {
            lastSkipNotice = skipAt
            val remaining = 5_000_000_000L - (System.nanoTime() - skipAt)
            // 重开界面不重放过期事件，也不延长仍在显示的提示。
            if (skipAt != 0L && remaining > 0L) Library.showTemporaryStatus(
                I18n.text("This song could not be played. Skipped to the next song."), remaining / 1_000_000L)
        }
        val failures = me.sorihiko.dango.party.ListenParty.members.filter {
            it.failedTrack.isNotEmpty() && it.failedTrack == t?.key
        }.map { it.uid + ":" + it.failedTrack }.toSet()
        if ((failures - failedMembers).isNotEmpty()) {
            Library.showTemporaryStatus(I18n.text("Someone in the room cannot play this song. Check the room member list; account access, region or network may be the cause."), 8_000L)
        }
        failedMembers = failures
        if (sub != lastSubtitle) { lastSubtitle = sub; subtitleAt = System.nanoTime() }
        val overflow = ui.width(sub, 11f) - infoW
        if (MusicPlayer.message.isNotEmpty() && overflow > 0f) {
            val seconds = (System.nanoTime() - subtitleAt) / 1e9
            val travel = overflow / 28.0
            val phase = seconds % (travel * 2 + 3)
            val offset = when {
                phase < 1.5 -> 0f
                phase < 1.5 + travel -> ((phase - 1.5) * 28).toFloat()
                phase < 3 + travel -> overflow
                else -> (overflow - (phase - 3 - travel) * 28).toFloat()
            }
            ui.beginClip(LayoutBounds(infoX, coverBox.y + 23f, infoW, 20f))
            ui.text(sub, infoX - offset, coverBox.y + 27f, 11f, Theme.TEXT_SECONDARY)
            ui.endClip()
        } else if (t != null && MusicPlayer.message.isEmpty()) {
            // 歌手名可以点，打开歌手页
            drawArtistLinks(screen, t, infoX, coverBox.y + 27f, infoW, 11f, Theme.TEXT_SECONDARY)
        } else ui.text(ui.trim(sub, infoW, 11f), infoX, coverBox.y + 27f, 11f, Theme.TEXT_SECONDARY)

        // 网易云：红心（登录了才有）
        if (t != null && likeShown) {
            Library.ensureLiked(t)
            val likeB = LayoutBounds(infoX + infoW + 8f, coverBox.y + cs / 2f - 14f, 28f, 28f)
            val k = button(likeB, likeA)
            val on = likeA.on.tick(if (Library.isLiked(t)) 1f else 0f).coerceIn(0f, 1f)
            ui.icon("♥", likeB.x + 14f, likeB.y + 14f, 15f * k, mixColor(Theme.TEXT_SECONDARY, RED, on))
            ui.hits += likeB to { likeA.press.v -= 7f; Library.toggleLike(t) }
        }
        // 加到歌单（红心右边；没有红心就在红心的位置）
        if (t != null && addShown) {
            val ax = infoX + infoW + 8f + (if (likeShown) 32f else 0f)
            add.drawButton(LayoutBounds(ax, coverBox.y + cs / 2f - 14f, 28f, 28f), t)
        }

        // 中：上一首 / 播放 / 下一首 / 队列。点击区域固定，动画只改画出来的样子
        val cx = bar.x + bar.width / 2f
        val cy = ry
        val playB = LayoutBounds(cx - 24f, cy - 24f, 48f, 48f)
        val prevB = LayoutBounds(cx - 62f - 16f, cy - 16f, 32f, 32f)
        val nextB = LayoutBounds(cx + 62f - 16f, cy - 16f, 32f, 32f)
        val queueB = LayoutBounds(cx + 112f - 16f, cy - 16f, 32f, 32f)
        // 播放模式（顺序 / 随机 / 单曲循环）：和右边的队列按钮对称
        val modeB = LayoutBounds(cx - 112f - 16f, cy - 16f, 32f, 32f)
        drawModeButton(modeB, cy)
        val kPrev = button(prevB, prevA)
        val kPlay = drawPlayDisc(playB)
        val kNext = button(nextB, nextA)
        val kQueue = button(queueB, queueA)
        // 播放 ↔ 暂停：两个图标交叉淡入淡出，暂停的两道竖条从中间长出来，三角形收小淡出
        val p = playMorph.tick(if (MusicPlayer.shownState == MusicPlayer.State.PLAYING) 1f else 0f).coerceIn(0f, 1f)
        if (p > 0.01f) {
            ctx.pushOpacity(p)
            val bh = 16f * kPlay * (0.55f + 0.45f * p)
            ui.card(LayoutBounds(cx - 6f * kPlay, cy - bh / 2f, 4f * kPlay, bh), Theme.TEXT_PRIMARY, 1.5f)
            ui.card(LayoutBounds(cx + 2f * kPlay, cy - bh / 2f, 4f * kPlay, bh), Theme.TEXT_PRIMARY, 1.5f)
            ctx.popOpacity()
        }
        if (p < 0.99f) {
            ctx.pushOpacity(1f - p)
            ui.icon("▶", cx + 1.5f * kPlay, cy, 18f * kPlay * (1f - 0.35f * p), Theme.TEXT_PRIMARY)
            ctx.popOpacity()
        }
        // ⏮ = 竖条 + ◀，⏭ = ▶ + 竖条（围绕按钮中心缩放）
        // 按钮宽 32，中心在 16。⏮ 是竖条（左）+ ◀（右），组合的中心比 pc 偏右 1.25，所以 pc 往左挪回来
        val pc = prevB.x + prevB.width / 2f - 1.25f * kPrev
        ui.card(LayoutBounds(pc - 6f * kPrev, cy - 5.5f * kPrev, 2.2f * kPrev, 11f * kPrev), Theme.TEXT_PRIMARY, 1f)
        ui.icon("◀", pc + 2.5f * kPrev, cy, 12f * kPrev, Theme.TEXT_PRIMARY)
        // ⏭ 是 ▶（左）+ 竖条（右），组合的中心比 nc 偏左 1.25
        val nc = nextB.x + nextB.width / 2f + 1.25f * kNext
        ui.icon("▶", nc - 2.5f * kNext, cy, 12f * kNext, Theme.TEXT_PRIMARY)
        ui.card(LayoutBounds(nc + 3.8f * kNext, cy - 5.5f * kNext, 2.2f * kNext, 11f * kNext), Theme.TEXT_PRIMARY, 1f)
        val q = queueA.on.tick(if (ScreenState.page == Page.QUEUE) 1f else 0f)
        ui.icon("≡", queueB.x + queueB.width / 2f, cy, 14f * kQueue, mixColor(Theme.TEXT_PRIMARY, RED, q))
        ui.hits += prevB to { prevA.press.v -= 7f; MusicPlayer.prev() }
        ui.hits += playB to { playA.press.v -= 7f; MusicPlayer.togglePause() }
        ui.hits += nextB to { nextA.press.v -= 7f; MusicPlayer.next() }
        ui.hits += queueB to {
            queueA.press.v -= 7f
            if (ScreenState.page == Page.QUEUE) screen.goBackOrHome() else screen.go(Page.QUEUE)
        }

        // 进度条：在栏的底部，两端上方标时间（当前时间亮一点）；鼠标移上去变粗、出现圆钮
        val dur = MusicPlayer.shownDurationMs
        val pos = MusicPlayer.shownPositionMs
        // 两头各留一段，不贴着播放栏的圆角
        progRect = LayoutBounds(bar.x + PROGRESS_INSET, bar.bottom - 11f, bar.width - PROGRESS_INSET * 2, 3f)
        val kn = progKnob.tick(if (seeking || progRect.expand(0f, 6f).contains(ui.mx, ui.my)) 1f else 0f).coerceIn(0f, 1.2f)
        val l = fmtTime(if (seeking && dur > 0) (seekFraction * dur).toLong() else pos)
        val rgt = fmtTime(dur)
        ui.text(l, progRect.x, progRect.y - 14f, 9.5f, Theme.TEXT_PRIMARY.copy(a = 0.9f), Theme.FONT_SEMIBOLD)
        ui.text(rgt, progRect.right - ui.width(rgt, 9.5f, Theme.FONT_SEMIBOLD), progRect.y - 14f, 9.5f, Theme.TEXT_TERTIARY, Theme.FONT_SEMIBOLD)
        val thick = 3f + 2f * kn.coerceAtMost(1f)
        val lane = LayoutBounds(progRect.x, progRect.y + 1.5f - thick / 2f, progRect.width, thick)
        ui.card(lane, Color(1f, 1f, 1f, 0.08f), thick / 2f)
        if (dur > 0) {
            val f = if (seeking) seekFraction else (pos.toDouble() / dur).coerceIn(0.0, 1.0).toFloat()
            ui.card(LayoutBounds(lane.x, lane.y, max(thick, lane.width * f), lane.height), RED, thick / 2f)
            if (kn > 0.01f) {
                val kx = lane.x + lane.width * f
                val ks = 12f * kn
                ctx.drawShape(LayoutBounds(kx - ks / 2f, progRect.y + 1.5f - ks / 2f, ks, ks), ShapeStyle(RED, ks / 2f))
            }
        }

        // 右：均衡器、变速变调 + 音量
        val vy = ry
        // 右边喇叭图标的右边缘对齐进度条的右端；窗口窄时先缩短音量条，再窄就不画音量条（按钮不和队列按钮挤在一起）
        val rightEdge = bar.right - PROGRESS_INSET - 14f
        val rightSpace = rightEdge - (cx + 112f + 28f)
        // 均衡器左边再放音质标签（有歌在放时）
        val qualityW = if (quality.available) quality.buttonWidth() + 4f else 0f
        val buttons = BTN_STEP * 2 + qualityW
        val showVolume = rightSpace >= VOL_GAP + buttons + VOL_MIN
        var tuneX: Float
        if (showVolume) {
            val volW = (rightSpace - VOL_GAP - buttons).coerceIn(VOL_MIN, 110f)
            volRect = LayoutBounds(rightEdge - volW, vy - 2f, volW, 4f)
            speaker(volRect.x - 22f, vy, false)
            speaker(volRect.right + 9f, vy, true)
            ui.card(volRect, Theme.TRACK, 2f)
            ui.card(LayoutBounds(volRect.x, volRect.y, max(4f, volRect.width * MusicPlayer.volume), volRect.height), RED, 2f)
            val knobX = volRect.x + volRect.width * MusicPlayer.volume
            ctx.drawShape(LayoutBounds(knobX - 5f, volRect.y - 3f, 10f, 10f), ShapeStyle(Theme.TEXT_PRIMARY, 5f))
            tuneX = volRect.x - VOL_GAP - BTN_STEP + 4f
        } else {
            volRect = LayoutBounds()
            tuneX = rightEdge + 14f - 32f
        }
        // 变速变调紧挨着音量，均衡器再往左一个
        tune.drawButton(LayoutBounds(tuneX, vy - 14f, 32f, 28f), vy)
        // 均衡器：再往左一个
        eq.drawButton(LayoutBounds(tuneX - BTN_STEP, vy - 14f, 32f, 28f), vy)
        // 和均衡器之间留 4，和均衡器、调音之间的间距一样
        if (qualityW > 0f) quality.drawButton(tuneX - BTN_STEP - qualityW, vy)
        tune.drawPanel(bar)
        eq.drawPanel(bar)
        add.drawPanel(bar)
        quality.drawPanel(bar)
    }

    /**
     * 播放模式按钮，图标用线条画：顺序 = 两条平行的右箭头，单曲循环 = 圆圈箭头里一个 1，随机 = 两条交叉的箭头。
     * 不是顺序时图标是红色
     */
    private fun drawModeButton(b: LayoutBounds, cy: Float) {
        val k = button(b, modeA)
        val shuffle = MusicPlayer.shuffle
        val one = MusicPlayer.repeatOne
        val o = modeA.on.tick(if (shuffle || one) 1f else 0f).coerceIn(0f, 1f)
        val c = mixColor(Theme.TEXT_PRIMARY, RED, o)
        val mx = b.x + b.width / 2f
        // 和上一首 / 下一首的竖条一样粗：着色器的抗锯齿往里淡出 1 像素，太细会整条发虚
        val t = 2.2f * k
        when {
            one -> {
                // 带缺口的圆弧：从右侧稍下方开始顺时针绕到顶部偏右，缺口留在右上方，箭头在终点顺着圆弧方向
                val r = 7.5f * k
                val from = 10.0
                val to = 280.0
                val steps = 9
                for (i in 0 until steps) {
                    val a1 = Math.toRadians(from + (to - from) * i / steps)
                    val a2 = Math.toRadians(from + (to - from) * (i + 1) / steps)
                    segment(mx + (Math.cos(a1) * r).toFloat(), cy + (Math.sin(a1) * r).toFloat(),
                        mx + (Math.cos(a2) * r).toFloat(), cy + (Math.sin(a2) * r).toFloat(), t, c)
                }
                val end = Math.toRadians(to)
                // 顺时针方向的切线：(-sin, cos)
                val dir = Math.toDegrees(Math.atan2(Math.cos(end), -Math.sin(end))).toFloat()
                arrowHead(mx + (Math.cos(end) * r).toFloat(), cy + (Math.sin(end) * r).toFloat(), dir, 3.8f * k, t, c)
                val size = 9f * k
                ui.text("1", mx - ui.width("1", size, Theme.FONT_SEMIBOLD) / 2f, cy - size * 0.39f - 0.3f, size, c, Theme.FONT_SEMIBOLD)
            }
            shuffle -> {
                // 两条 S 形交叉的线：左右两端水平，中间斜着交叉，右端的箭头朝右
                val left = mx - 8f * k
                val bend1 = mx - 3.5f * k
                val bend2 = mx + 3f * k
                val right = mx + 7.5f * k
                val dy = 4.5f * k
                for (sign in floatArrayOf(-1f, 1f)) {
                    val y1 = cy + sign * dy
                    val y2 = cy - sign * dy
                    segment(left, y1, bend1, y1, t, c)
                    segment(bend1, y1, bend2, y2, t, c)
                    segment(bend2, y2, right, y2, t, c)
                    arrowHead(right, y2, 0f, 3.8f * k, t, c)
                }
            }
            else -> {
                // 两条平行的右箭头
                for (dy in floatArrayOf(-3.5f * k, 3.5f * k)) {
                    segment(mx - 8f * k, cy + dy, mx + 7.5f * k, cy + dy, t, c)
                    arrowHead(mx + 7.5f * k, cy + dy, 0f, 3.8f * k, t, c)
                }
            }
        }
        ui.hits += b to {
            modeA.press.v -= 7f
            Library.showTemporaryStatus(I18n.text(module.cyclePlayMode()), 1_500L)
        }
    }

    /**
     * 画一条从 (x1, y1) 到 (x2, y2)、粗 [thick] 的线：两头各多出半个线宽做成胶囊，
     * 再短的线段也画得出来（圆角不会超过宽度的一半），相邻线段在接缝处自然重叠成圆角
     */
    private fun segment(x1: Float, y1: Float, x2: Float, y2: Float, thick: Float, color: Color) {
        // 水平 / 竖直的线对齐到屏幕像素：界面缩放不是整数时，几条平行线会落在像素格的不同位置，
        // 有的实、有的被抗锯齿摊开，看着粗细不一样
        if (abs(y1 - y2) < 0.01f || abs(x1 - x2) < 0.01f) {
            ui.crispLine(x1, y1, x2, y2, thick, color)
            return
        }
        val len = Math.hypot((x2 - x1).toDouble(), (y2 - y1).toDouble()).toFloat()
        val ang = Math.toDegrees(Math.atan2((y2 - y1).toDouble(), (x2 - x1).toDouble())).toFloat()
        val ctx = ui.ctx
        ctx.pushTranslate((x1 + x2) / 2f, (y1 + y2) / 2f, 0f)
        ctx.pushRotate(ang, 0f, 0f, 1f)
        val full = len + thick
        ui.card(LayoutBounds(-full / 2f, -thick / 2f, full, thick), color, thick / 2f)
        ctx.popTransform()
        ctx.popTransform()
    }

    /** 箭头尖在 (x, y)，朝 [degrees] 方向（0 = 向右），两边各一道 [size] 长的斜线 */
    private fun arrowHead(x: Float, y: Float, degrees: Float, size: Float, thick: Float, color: Color) {
        for (side in floatArrayOf(-1f, 1f)) {
            val a = Math.toRadians((degrees + 180f + side * 42f).toDouble())
            segment(x, y, x + (Math.cos(a) * size).toFloat(), y + (Math.sin(a) * size).toFloat(), thick, color)
        }
    }

    /**
     * 播放栏的底：和侧栏同一种液态玻璃，圆角更大；下面压着一团强调色的光晕
     */
    private fun drawPanel(bar: LayoutBounds) {
        val glowW = bar.width * 0.6f
        ui.ctx.drawShape(LayoutBounds(bar.x + (bar.width - glowW) / 2f, bar.bottom - 40f, glowW, 36f),
            ShapeStyle(Color.TRANSPARENT, 18f, shadow = ShadowStyle(RED.copy(a = 0.12f), 30f, Vec2(0f, -6f))))
        ui.ctx.drawGlass(bar, BAR_GLASS)
    }

    /**
     * 播放键：实心的强调色圆；正在播放时外面一圈一圈地往外扩散。
     * 返回当前的缩放（悬停放大、点击回弹），里面的图标按它缩放
     */
    private fun drawPlayDisc(b: LayoutBounds): Float {
        val ctx = ui.ctx
        val hover = playA.hover.tick(if (ui.hover(b)) 1f else 0f).coerceIn(0f, 1f)
        val k = 1f + playA.press.tick(0f) * 0.14f + hover * 0.06f
        if (MusicPlayer.shownState == MusicPlayer.State.PLAYING) {
            val phase = (System.nanoTime() / 1e9 % 2.8 / 2.8).toFloat()
            if (phase < 0.7f) {
                val ring = b.scaled(k * (1f + 0.4f * phase / 0.7f))
                ctx.drawShape(ring, ShapeStyle(Color.TRANSPARENT, ring.height / 2f, 1.5f, RED.copy(a = 0.7f * (1f - phase / 0.7f))))
            }
        }
        val disc = b.scaled(k)
        ctx.drawShape(disc, ShapeStyle(RED, disc.height / 2f))
        return k
    }

    /** 圆形按钮的底：悬停时渐显、跟着点击回弹；返回当前的缩放，图标按它缩放 */
    private fun button(b: LayoutBounds, a: Anim): Float {
        val h = a.hover.tick(if (ui.hover(b)) 1f else 0f).coerceIn(0f, 1f)
        val k = 1f + a.press.tick(0f) * 0.14f + h * 0.04f
        if (h > 0.01f) {
            val d = b.scaled(k)
            ui.ctx.drawShape(d, ShapeStyle(Theme.CARD_HOVER.copy(a = Theme.CARD_HOVER.a * h), d.height / 2f))
        }
        return k
    }

    /** 随机 / 单曲循环：选中的红底渐入渐出，点击先缩再弹回 */
    private fun toggleButton(b: LayoutBounds, vy: Float, on: Boolean, a: Anim, glyph: String, action: () -> Unit) {
        val o = a.on.tick(if (on) 1f else 0f).coerceIn(0f, 1f)
        val h = a.hover.tick(if (ui.hover(b)) 1f else 0f).coerceIn(0f, 1f)
        val k = 1f + a.press.tick(0f) * 0.14f
        val base = mixColor(Color(1f, 1f, 1f, 0.07f), Theme.CARD_HOVER, h)
        ui.card(b.scaled(k), mixColor(base, RED.copy(a = 0.85f), o), 9f * k)
        ui.icon(glyph, b.x + 16f, vy, 14f * k, Theme.TEXT_PRIMARY)
        ui.hits += b to {
            a.press.v -= 7f
            action()
        }
    }

    /** 小喇叭图标：方块 + 喇叭口，loud = 右边再加两道声波 */
    private fun speaker(x: Float, cy: Float, loud: Boolean) {
        ui.card(LayoutBounds(x, cy - 2.5f, 3.5f, 5f), Theme.TEXT_SECONDARY, 1f)
        ui.card(LayoutBounds(x + 3f, cy - 5f, 3.5f, 10f), Theme.TEXT_SECONDARY, 1.2f)
        if (loud) {
            ui.card(LayoutBounds(x + 8.5f, cy - 2.5f, 1.4f, 5f), Theme.TEXT_SECONDARY, 0.7f)
            ui.card(LayoutBounds(x + 11.5f, cy - 4.5f, 1.4f, 9f), Theme.TEXT_SECONDARY, 0.7f)
        }
    }

    /** 点在进度条 / 音量条上就处理掉，返回 true；按在进度条上开始拖动 */
    fun mouseDown(mx: Int, my: Int): Boolean {
        if (tune.mouseDown(mx, my)) return true
        if (eq.mouseDown(mx, my)) return true
        if (add.mouseDown(mx, my)) return true
        if (quality.mouseDown(mx, my)) return true
        if (progRect.expand(0f, 6f).contains(mx, my)) {
            if (MusicPlayer.shownDurationMs > 0) {
                seeking = true
                seekFraction = fractionAt(mx)
            }
            return true
        }
        if (volRect.width > 0f && volRect.expand(6f, 8f).contains(mx, my)) {
            setVolumeAt(mx)
            return true
        }
        return false
    }

    /** 按住拖动：拖进度条时跟着鼠标走（拖出条外也算），否则拖音量 */
    fun mouseDrag(mx: Int, my: Int) {
        if (tune.dragging) {
            tune.mouseDrag(mx)
            return
        }
        if (eq.dragging) {
            eq.mouseDrag(my)
            return
        }
        if (seeking) {
            seekFraction = fractionAt(mx)
            return
        }
        if (volRect.width > 0f && volRect.expand(12f, 12f).contains(mx, my)) setVolumeAt(mx)
    }

    /** 松开鼠标：拖进度条的话现在才跳过去 */
    fun mouseUp() {
        tune.mouseUp()
        eq.mouseUp()
        if (!seeking) return
        seeking = false
        val dur = MusicPlayer.shownDurationMs
        if (dur > 0) MusicPlayer.seek((seekFraction * dur).toLong())
    }

    private fun fractionAt(x: Int): Float =
        if (progRect.width <= 0f) 0f else ((x - progRect.x) / progRect.width).coerceIn(0f, 1f)

    private fun setVolumeAt(x: Int) {
        // 音量条还没画出来（宽度是 0）时算出来是 NaN
        if (volRect.width <= 0f) return
        val v = ((x - volRect.x) / volRect.width).coerceIn(0f, 1f)
        module.setVolume(v)
        MusicPlayer.volume = v
    }
}

/** 播放栏的玻璃：用侧栏那一套，圆角放大、阴影比侧栏淡一点 */
private val BAR_GLASS = Theme.GLASS_SIDEBAR.copy(radius = 28f, shadow = ShadowStyle(Color(0f, 0f, 0f, 0.10f), 14f, Vec2(0f, -3f)))
/** 右边小按钮的间隔（按钮 32 宽） */
private const val BTN_STEP = 36f
/** 最靠右的按钮和音量条之间：留给左边的小喇叭 */
private const val VOL_GAP = 32f
/** 音量条最短 */
private const val VOL_MIN = 40f
/** 进度条离播放栏左右两边的距离 */
private const val PROGRESS_INSET = 72f
