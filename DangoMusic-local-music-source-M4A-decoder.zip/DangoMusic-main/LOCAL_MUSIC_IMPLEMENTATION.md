# Dango Music — Local Music implementation notes

Target: Minecraft 1.21.1 / NeoForge (Dango Music 1.7.6 source tree)

## Changes

- Adds a `Local Music` entry to Dango's sidebar.
- Recursively scans the configured folder and all readable child folders. The initial default is `/storage/emulated/0/VidMate/download`; the Local Music page lets you edit the folder path and press **Scan**. The path is saved in `config/local-music-path.txt`.
- Discovers `.mp3`, `.flac`, `.ogg`, `.m4a`, and `.aac` (ADTS) files.
- Reuses Dango's existing queue, player bar, pause/seek, volume, and audio-output pipeline.
- Local tracks are device-only and are intentionally blocked while in Listen Together.
- M4A/MP4/AAC decoding uses a pure-Java AAC-LC decoder (`common/core/src/main/java/me/sorihiko/dango/music/aac/`). Zalith/PojavLauncher run a desktop-style JVM that has no `android.media` classes, so the earlier `MediaExtractor`/`MediaCodec` reflection path could never work there. The new decoder reads the MP4 container itself (normal and fragmented MP4, ADTS) and outputs PCM16 mono/stereo into the existing player pipeline. Song length comes from the container, so the progress bar and seeking work.

## Android notes / limitations

- The launcher process must be allowed to read the shared-storage folder. Grant the Android storage/media access permission to the launcher (Zalith) if the scan reports permission denied. The mod cannot override Android storage restrictions.
- Supported M4A audio: AAC-LC (what iTunes, YouTube/VidMate downloads, ffmpeg and most encoders produce), mono or stereo (5.1/7.1 is downmixed to stereo). HE-AAC (SBR/PS) plays at the core bandwidth, so very high frequencies are missing. Not supported: ALAC (Apple Lossless), AAC Main/LTP, and non-AAC audio inside MP4.
- Local `.ogg` support is the existing Dango Vorbis decoder; Ogg Opus remains unsupported by the existing decoder.
- The directory is rescanned when the Local Music page is opened or when you press **Scan** after editing the path. The path is stored in the mod config folder and reused after restarting Minecraft.

## Build

Use JDK 21 and a network-enabled Gradle environment, from this directory:

```bash
cd modern
sh gradlew :1.21.1-neoforge:remapJar
```

Expected output:

`modern/versions/1.21.1-neoforge/build/libs/DangoMusic-1.7.6+1.21.1-neoforge.jar`

## Verification status

The AAC decoder was checked against ffmpeg on synthetic audio (mono/stereo, 8-96 kHz, 32-320 kbps, M/S, intensity, PNS, TNS, short windows, fragmented MP4, ADTS): output matches to within 1 LSB of 16-bit PCM. The whole `common/` tree compiles. The in-game UI and Android audio output could not be run in the build environment, so test the built JAR in Zalith.

## Build from a phone using GitHub Actions

A workflow is included at `.github/workflows/build-neo-forge-1.21.1.yml`. After pushing this source tree to a GitHub repository, open **Actions → Build Dango Music (NeoForge 1.21.1) → Run workflow**. When it finishes, open the run and download the artifact named `DangoMusic-1.7.6-1.21.1-neoforge-local-music`.
